package com.example.pokemon2.data

data class AbilityInfo(
    val name: String,
    val url: String
)